// netlify/functions/jotform-submit.js
// Submits one chore/laundry record to Jotform. The API key stays private on the server.
// Field QIDs are looked up by label text at request time, so this works regardless of
// Jotform's internal numbering and survives the form being edited later.

let fieldCache = null; // {name:qid, chore:qid, earnings:qid, date:qid, time:qid}
let fieldCacheAt = 0;

async function getFieldMap(API_KEY, FORM_ID) {
  if (fieldCache && Date.now() - fieldCacheAt < 10 * 60 * 1000) return fieldCache;
  const resp = await fetch(`https://api.jotform.com/form/${FORM_ID}/questions?apiKey=${API_KEY}`);
  const json = await resp.json();
  const qs = json.content || {};
  const map = {};
  for (const qid in qs) {
    const q = qs[qid];
    const label = (q.text || q.name || "").toLowerCase();
    if (label.includes("child")) map.name = qid;
    else if (label.includes("chore")) map.chore = qid;
    else if (label.includes("earning")) map.earnings = qid;
    else if (q.type === "control_datetime" || label.includes("date")) map.date = qid;
    else if (label.includes("time")) map.time = qid;
    else if (label.includes("photo")) map.photo = qid;
  }
  fieldCache = map;
  fieldCacheAt = Date.now();
  return map;
}

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method not allowed" };
  }
  const API_KEY = process.env.JOTFORM_API_KEY;
  const FORM_ID = process.env.JOTFORM_FORM_ID;
  if (!API_KEY || !FORM_ID) {
    return { statusCode: 500, body: JSON.stringify({ error: "Server not configured" }) };
  }

  let data;
  try { data = JSON.parse(event.body); }
  catch (e) { return { statusCode: 400, body: JSON.stringify({ error: "Bad request body" }) }; }

  let map;
  try { map = await getFieldMap(API_KEY, FORM_ID); }
  catch (e) { return { statusCode: 502, body: JSON.stringify({ error: "Could not read form fields", detail: String(e) }) }; }

  const params = new URLSearchParams();
  if (map.name) params.append(`submission[${map.name}]`, data.child || "");
  if (map.chore) params.append(`submission[${map.chore}]`, data.chore || "");
  if (map.earnings) params.append(`submission[${map.earnings}]`, data.earnings || "");
  if (map.date) {
    params.append(`submission[${map.date}][month]`, data.month || "");
    params.append(`submission[${map.date}][day]`, data.day || "");
    params.append(`submission[${map.date}][year]`, data.year || "");
  }
  if (map.time) {
    params.append(`submission[${map.time}][hour]`, data.hour || "");
    params.append(`submission[${map.time}][minute]`, data.minute || "");
    params.append(`submission[${map.time}][ampm]`, data.ampm || "");
  }

  try {
    const resp = await fetch(
      `https://api.jotform.com/form/${FORM_ID}/submissions?apiKey=${API_KEY}`,
      { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: params.toString() }
    );
    const json = await resp.json();
    return { statusCode: 200, body: JSON.stringify(json) };
  } catch (e) {
    return { statusCode: 502, body: JSON.stringify({ error: "Jotform request failed", detail: String(e) }) };
  }
};
